#ifndef Orion_WDM_h
#define Orion_WDM_h

#include "Arduino.h"

#define ADELANTE 1
#define ATRAS    2

class Orion_WDM {
  public:
    Orion_WDM(int pwma, int ain1, int ain2, int pwmb, int bin1, int bin2);
    void motorA(int direccion, int velocidad);
    void motorB(int direccion, int velocidad);
    void mover(int dirA, int velA, int dirB, int velB);
    void stop();
  private:
    int _pwma, _ain1, _ain2;
    int _pwmb, _bin1, _bin2;
};

#endif
