#include "Orion_WDM.h"

Orion_WDM::Orion_WDM(int pwma, int ain1, int ain2, int pwmb, int bin1, int bin2) {
  _pwma = pwma; _ain1 = ain1; _ain2 = ain2;
  _pwmb = pwmb; _bin1 = bin1; _bin2 = bin2;

  pinMode(_pwma, OUTPUT);
  pinMode(_ain1, OUTPUT);
  pinMode(_ain2, OUTPUT);
  pinMode(_pwmb, OUTPUT);
  pinMode(_bin1, OUTPUT);
  pinMode(_bin2, OUTPUT);
}

void Orion_WDM::motorA(int direccion, int velocidad) {
  analogWrite(_pwma, velocidad);
  if (direccion == ADELANTE) {
    digitalWrite(_ain1, HIGH);
    digitalWrite(_ain2, LOW);
  } else {
    digitalWrite(_ain1, LOW);
    digitalWrite(_ain2, HIGH);
  }
}

void Orion_WDM::motorB(int direccion, int velocidad) {
  analogWrite(_pwmb, velocidad);
  if (direccion == ADELANTE) {
    digitalWrite(_bin1, HIGH);
    digitalWrite(_bin2, LOW);
  } else {
    digitalWrite(_bin1, LOW);
    digitalWrite(_bin2, HIGH);
  }
}

void Orion_WDM::mover(int dirA, int velA, int dirB, int velB) {
  motorA(dirA, velA);
  motorB(dirB, velB);
}

void Orion_WDM::stop() {
  analogWrite(_pwma, 0);
  analogWrite(_pwmb, 0);
  digitalWrite(_ain1, LOW);
  digitalWrite(_ain2, LOW);
  digitalWrite(_bin1, LOW);
  digitalWrite(_bin2, LOW);
}
